# -*- coding: utf-8 -*-
"""
An excel capture program created by Marty
09.15.2020 created file

"""


from win32com.client import Dispatch, DispatchEx
import pythoncom
from PIL import ImageGrab, Image
import datetime
import time
import xlwings as xw 
from shutil import copyfile





def start():
    screen_area = 'A1:X3'
    print(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')+' : program start')
    
    
    oringin = r'C:/Users/Marty/Desktop/for_demo/files/demo0.xls'
    
    for i in range(0,12):#改成你要的次数来做循环
        filename = r'C:/Users/Marty/Desktop/for_demo/files/demo'+str(i)+'.xls'
        target = r'C:/Users/Marty/Desktop/for_demo/files/demo'+str(i+1)+'.xls'
        # print(filename)
        copyfile(filename, target)
        cap(filename,screen_area,target)
    
    
    
    print(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')+' : end of program') 


def cap(filename, screen_area, target):
    pythoncom.CoInitialize()  #excel多线程相关
    excel = DispatchEx("Excel.Application")  #启动excel
    
    wb = excel.Workbooks.Open(filename)#打开excel
    ws = wb.Worksheets('Sheet1')  #选择sheet
    #print(ws.Range(screen_area).Value)
    ws.Range(screen_area).CopyPicture()
    ws.Paste(ws.Range(screen_area))# 变成图片
    
    name = ws.Range("C3").Value
    ID = ws.Range("B3").Value
    print(name)
    print(ID)
    
    excel.Selection.ShapeRange.Name = name#将刚刚选择的Shape重命名，避免与已有图片混淆
    ws.Shapes(name).Copy()
    img = ImageGrab.grabclipboard()  # 获取剪贴板的图片数据
    img_name = ID + "_" + name + ".PNG" #生成图片的文件名
    img.save(img_name)  #保存图片

    
    #ws.delete_cols(13) #删除第 13 列数据
    #ws.delete_rows(3) #删除第 3行数据
    
    wb_delete = xw.Book(target)
    #wb_delete.app.calculation = 'automatic'
    sht = wb_delete.sheets[0]
    sht.range('A3:X3').api.Delete()
    
    wb_delete.save(target)
    wb_delete.close()
    wb.Save()
    wb.Close()
if __name__ == "__main__":
    start() 